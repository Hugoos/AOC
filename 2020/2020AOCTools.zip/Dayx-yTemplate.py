import math
from AOCTools import *
fileName = "input/inputX.txt" #Stop de input in een input mapje (met het nummer van de dag erachter) en verander de X in het nummer van de dag

#Uncomment de parsing strategie die je wilt gebruiken om de input te lezen.
#lines= read_integers(fileName) #read_integers leest de file als lijst van integers e.g. als de input "1943\n2938\n2003" is dan krijg je [int(1943),int(2938),int(2003)] terug. Note "\n" is newline.
#lines= read_strings(fileName) #read_strings zonder extra parameters leest de file in als lijst van strings e.g. als de input "1943\n2938\n2003" is dan krijg je [str(1943),str(2938),str(2003)] terug. 
#lines= read_strings(fileName, deliminator=",") #read_strings met deliminator leest de file in als lijst van strings gescheiden door de deliminator e.g. als de input "1943,2938,2003" is dan krijg je [str(1943),str(2938),str(2003)] terug.


#for line in lines:  #Zo kan je over iedere lijn itereren
#   do something
